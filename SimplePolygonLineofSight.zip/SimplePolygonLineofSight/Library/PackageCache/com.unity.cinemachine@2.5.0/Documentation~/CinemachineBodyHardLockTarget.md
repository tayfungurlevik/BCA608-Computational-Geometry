# Hard Lock to Target

This Virtual Camera __Body__ algorithm uses the same position at the __Follow__ target. In other words, the target acts as a mounting point for the Virtual Camera.

